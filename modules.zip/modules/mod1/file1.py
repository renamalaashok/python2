a=100
def fun2():
	return "this is fun2 in file1.py"
def main():
	print "progrma started"
	print fun2()
	print "program ended"

if __name__ == "__main__":
	main()
	
