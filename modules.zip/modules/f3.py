a=100
def fun2():
	return "this is fun2 in f2.py"
if __name__ == "__main__":
	print "progrma started"
	print fun2()
	print "program ended"
