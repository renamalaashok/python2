import sys
print sys.argv

# copy a file
# python copy_file.py source destination