a=100
print "progrma started"
def fun2():
	return "this is fun2 in f2.py"
print fun2()
print "program ended"
