'''
import f1
print f1.fun1()
'''''
'''
import f2
print f2.fun2()
def fun3():
	c=f2.a
'''
'''
import f4
print f4.fun2()
print f4.main()
'''
import mod1
print mod1.file1.fun2()
print mod1.file2.fun2()