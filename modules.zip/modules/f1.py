def fun1():
	return "this is fun1 in f1.py small change"