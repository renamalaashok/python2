
# coding: utf-8

# In[1]:

employee_name = "Anil"


# In[2]:

name1 = "Anil"


# In[3]:

1name = "sdfsdf"


# In[4]:

name@we = "sdfsdfds"


# In[5]:

name_wew = "dsfsdfd"


# In[6]:

asERT = "sdfsdf"


# In[7]:

for = "for loop"


# In[9]:

sum([10,20,304])


# In[10]:

sum = 1234


# In[11]:

print sum


# In[12]:

print "program started"
def fun():
    print "function started"
    print "this my first function"
    print "function ended"
print "other statemetns in program"
print "program ended"


# In[13]:

print "program started"
def fun():
    print "function started"
    print "this my first function"
    print "function ended"
fun()
print "other statemetns in program"
print "program ended"


# In[14]:

print "program started"
def fun():
print "function started"
print "this my first function"
print "function ended"
fun()
print "other statemetns in program"
print "program ended"


# In[15]:

print "program started"
def fun():
print "function started"
print "this my first function"
print "function ended"
fun()
print "other statemetns in program"
print "program ended"


# In[16]:

print "program started"
def fun():
    pass
print "function started"
print "this my first function"
print "function ended"
fun()
print "other statemetns in program"
print "program ended"


# In[17]:

print "program started"
def fun():
    pass
print "function started"
print "this my first function"
print "function ended"
print "other statemetns in program"
print "program ended"


# In[18]:

print "program started"
def fun():
    print "function started"
        print "this my first function"
            print "function ended"
print "other statemetns in program"
print "program ended"


# In[19]:

print "program started"
def fun():
    print "function started"
def fun1():
        print "this my first function"
def fun2():
            print "function ended"
        
print "other statemetns in program"
print "program ended"


# In[20]:

print "program started"
def fun():
    print "function started"
def fun1():
        print "this my first function"
        
def fun2():
            print "function ended"
        
        print "fun1 is ended"
        
print "other statemetns in program"
print "program ended"


# In[21]:

print "program started"
def fun():
    print "function started"
def fun1():
        print "this my first function"
        print "fun1 is ended"
        
def fun2():
            print "function ended"
        
        
        
print "other statemetns in program"
print "program ended"


# In[23]:

def fun(a,b):
    print a,b
    
fun(10,20)
    


# In[24]:

def fun(a,b):
    print a,b    
c=fun(10,20)
print c  


# In[26]:

def fun(a,b):
    print a,b  
    c1=a+b
    a=a+20
    b=b+200
    print a
    print b
    print c1
    return "return value"
c=fun(10,20)
print c  


# In[27]:

def fun(a,b):
    print a,b  
    c1=a+b
    a=a+20
    b=b+200
    print a
    print b
    print c1
    return a+b
c=fun(10,20)
print "c=",c  


# In[28]:

def fun(a,b):
    print a,b  
    c1=a+b
    a=a+20
    b=b+200
    print a
    print b
    print c1
    return a+b
c=fun(10,20)
print c


# In[29]:

s="pythn"


# In[ ]:

s.

