
# coding: utf-8

# In[1]:

a=raw_input("Enter data:")
print a
print type(a)


# In[2]:

a=raw_input("Enter data:")
print a
print type(a)


# In[3]:

a=input("Enter data:")
print a
print type(a)


# In[4]:

a=input("Enter data:")
print a
print type(a)


# In[5]:

print z


# In[6]:

name = "Anil"
age = 23
sal = 23456
height = 5.6
print name,age,sal,height


# In[7]:

# name: Anil, age: 23, sal: 23456, height: 5.6
print 'name:',name,"age:",age,'sal:',sal,"height:",height


# In[8]:

# name: Anil, age: 23, sal: 23456, height: 5.6
print 'name:',name,", age:",age,', sal:',sal,", height:",height


# In[9]:

print "str1"+"str2"


# In[10]:

# name: Anil, age: 23, sal: 23456, height: 5.6
print 'name:'+name+", age:"+age+', sal:'+sal+", height:"+height


# In[11]:

print "sal: "+23456


# In[12]:

print "sal: "+str(23456)


# In[13]:

# name: Anil, age: 23, sal: 23456, height: 5.6
print 'name:'+name+", age:"+str(age)+', sal:'+str(sal)+", height:"+str(height)


# In[14]:

# format specifiers


# In[15]:

print "%d%s%f%r"


# In[16]:

print "%d%s%f%r",(10,"python",12.34,23.45)


# In[17]:

print "%d%s%f%r"%(10,"python",12.34,23.45)


# In[18]:

print "%d,%s,%f,%r"%(10,"python",12.34,23.45)


# In[19]:

print "%d,%s,%f,%r"%(10,"python",12.34,23.45)


# In[20]:

print "%d"%23.34


# In[21]:

print "%f"%45


# In[22]:

print "name: %s, age: %d, sal: %d, height: %f"%(name,age,sal,height)


# In[23]:

print "%f"%23.4567812345


# In[24]:

print "%2f"%23.4567812345


# In[25]:

print "%.2f"%23.4567812345


# In[26]:

print "%.8f"%23.4567812345


# In[27]:

print "%10d"%123


# In[28]:

print 123


# In[29]:

print "%d"%123


# In[30]:

print "%10d"%123


# In[31]:

# it's a good day
print "it's a good day"


# In[32]:

print 'it's a good day'


# In[33]:

print 'it\'s a good day'


# In[34]:

# "samba" 'python'
print "\"samba\" 'python' "


# In[35]:

"""
name: Anil
sal: 23456
"""
print "name:",name
print "sal:",sal


# In[37]:

print "name: %s\nsal: %s"%(name,sal)


# In[38]:

print "newline \nline2\t tabspace"


# In[39]:

# line1\nline2\ttabspace\nline3
print "line1\nline2\ttabspace\nline3"


# In[40]:

# line1\nline2\ttabspace\nline3
print "line1\\nline2\\ttabspace\\nline3"


# In[41]:

print r"line1\nline2\ttabspace\nline3"


# In[42]:

len("python")


# In[43]:

len("\n\n\t")


# In[44]:

len(r"\n\n\t")


# In[45]:

# pep8 errors
a="python"*60
print a


# In[ ]:

def fun()
import module
print name, sal
def fun()
    pass

def fun1():


# In[46]:

a1 = "ssssssssssssssssssssssss"
a2 = "ssssssssssssssssss"
a3 = "sdfsfsdfsd"
a4 = "fsfsdf"
c=a1+a2+a3+a4


# In[47]:

c = "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
sdfsdf sdf sd fsd fsdf sdf
"


# In[48]:

c = "mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmsdfsdf sdf sd fsd fsdf sdf"


# In[49]:

print c


# In[50]:

c="name:",name+"name:123445"


# In[ ]:



