
# coding: utf-8

# In[1]:

s= "python program"
print len(s)


# In[2]:

s-1


# In[3]:

s[len(s)-1]


# In[4]:

s[-1]


# In[5]:

s[-3]


# In[6]:

print s[0-5]


# In[7]:

# slicing
print s[0:5]


# In[8]:

print s[0+5]


# In[9]:

s= "python program"
print s[2:5] # m:n from mth index to n-1 th index


# In[10]:

print s[0:6]


# In[11]:

print s[:6]


# In[12]:

print s[6:]


# In[13]:

print s[:]


# In[14]:

print s[6:-3]


# In[15]:

print s[-3:]


# In[16]:

print s[:3]


# In[17]:

print s[-5:]


# In[18]:

print s[10:1]


# In[19]:

print s[18]


# In[20]:

s[13]


# In[21]:

s[12]


# In[22]:

s[11]


# In[23]:

s


# In[24]:

s[7:17]


# In[25]:

s[17:23]


# In[26]:

s[17:17]


# In[27]:

s[3:3]


# In[28]:

s[3:4]


# In[29]:

s[17:18]


# In[30]:

s[5:6]


# In[31]:

s


# In[32]:

s[::1]


# In[33]:

s[::2]


# In[34]:

s[::-1]


# In[35]:

s[::-2]


# In[36]:

s[::-3]


# In[37]:

s[::3]


# In[38]:

a=raw_input("Enter a value:")
b=raw_input("Enter b value:")
print a+b


# In[39]:

print "str1"+"str2"


# In[40]:

a=raw_input("Enter a value:")
b=raw_input("Enter b value:")
a=int(a)
b=int(b)
print a+b


# In[41]:

s="12345"
print int(s)


# In[42]:

b=int("123")
print type(b)
print b


# In[43]:

print int(12.34)


# In[44]:

print int("12.34")


# In[45]:

get_ipython().magic(u'pinfo int')


# In[46]:

a=raw_input("Enter a value:")
b=raw_input("Enter b value:")
a=int(a)
b=int(b)
print a+b


# In[47]:

get_ipython().magic(u'pinfo int')


# In[ ]:

int("12.34")
#print 4*10**0+ 3*10**1+.*10**2
#0123456789


# In[48]:

a=raw_input("Enter a value:")
b=raw_input("Enter b value:")
a=float(a)
b=float(b)
print a+b


# In[49]:

int(12.34)


# In[50]:

int("12.34")


# In[51]:

float("12.34")


# In[52]:

get_ipython().magic(u'pinfo int')


# In[53]:

int("abc",13)


# In[54]:

int("abc")


# In[56]:

print 12*13**0 + 11*13**1 + 10*13**2


# In[57]:

int("123",2)


# In[58]:

a=raw_input("Enter a value:")
b=raw_input("Enter b value:")
a=float(a)
b=float(b)
print a+b


# In[59]:

get_ipython().magic(u'pinfo len')


# In[60]:

len("12345")


# In[61]:

len("python")


# In[62]:

len([1,2,3,4])


# In[63]:

len((1,2,34))


# In[64]:

a=9676622023
print a[1]


# In[68]:

a=9676622023
s1=str(a)


# In[69]:

print type(s1)


# In[71]:

s1[-4:]


# In[72]:

c1=1+2j


# In[73]:

print type(c1)


# In[75]:

c1=1+2j
c2=2+3j

print c1+c2
print c1-c2
print c1*c2
print c1/c2
print c1%2
print c1**2
print c2%2


# In[76]:

print "str1"+"str2"


# In[77]:

print "str1"+2


# In[79]:

print "str2"*2


# In[80]:

print "str1"*10


# In[ ]:



