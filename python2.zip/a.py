print "hello world"
a = 10
b = 20
c = a + b
print "changes"
print a,b,c
print a
print b
print c
