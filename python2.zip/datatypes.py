
# coding: utf-8

# In[1]:

a=10
b=20
c=30
print a,b,c


# In[3]:

print a+b+c
print a-b-c
print a*b*c
print "a/b=",a/b
print c**2
print b%4


# In[4]:

print 10.0/20


# In[5]:

print 10/20


# In[6]:

print 10/5


# In[7]:

print a,b


# In[8]:

print a/b.0


# In[9]:

print float(a)


# In[10]:

float(0)


# In[11]:

float(2)


# In[12]:

a=10
b=20
print float(a/b) # 0, 0.0, 0.5 None
# operator precedency


# In[13]:

float(0)


# In[14]:

print float(a)/b


# In[15]:

print a/float(b)


# In[16]:

print float(a)/float(b)


# In[17]:

a=raw_input("Enter a value:")
b=raw_input("Enter b value:")
print a,b


# In[18]:

print type(a),type(b)


# In[19]:

s = "python program"
s1 = 1234567


# In[20]:

a=100
print a
print "a"


# In[21]:

print 10


# In[22]:

print python


# In[23]:

print "python"


# In[24]:

s2 = python
s2 = "python"
s2= 'python'


# In[25]:

s = "python program"
s1 = 1234567


# In[26]:

print s[0],s[1],s[4]


# In[27]:

print s1[3]


# In[28]:

print "python" + "program"


# In[29]:

print "python" * "program"


# In[30]:

print "python "+2


# In[31]:

print "python" * 2


# In[32]:

print 12


# In[36]:

a=12
b=012


# In[37]:

print a


# In[38]:

print b


# In[39]:

print 2*8**0+1*8**1


# In[40]:

a=0xabc
b="0xabc"
print a
print b


# In[ ]:



